Instruções para rodar o projeto Interativa:

1. Rode `node seed.js` para criar os usuários no database.sqlite.
2. Rode `node server_jwt.js` para iniciar o servidor.
3. Abra http://localhost:3000 para acessar o front-end.

O projeto já está pronto para deploy no Render com render.yaml.
