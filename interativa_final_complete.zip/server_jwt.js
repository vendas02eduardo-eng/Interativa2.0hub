
// Express + JWT + SQLite mínimo
const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const bodyParser = require('body-parser');
const path = require('path');
const app = express();
const SECRET = 'interativa_secret';

app.use(bodyParser.json());
app.use(express.static(path.join(__dirname)));

const db = new sqlite3.Database('./database.sqlite');

app.listen(process.env.PORT || 3000, ()=>{ console.log('Server running'); });
