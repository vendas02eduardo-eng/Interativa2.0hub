
// Script para criar usuários e senhas hash
const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcryptjs');
const db = new sqlite3.Database('./database.sqlite');

db.serialize(()=>{
    db.run(`CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE, name TEXT, email TEXT UNIQUE, password TEXT, role TEXT, team TEXT)`);
    const stmt = db.prepare('INSERT OR IGNORE INTO users (username,name,email,password,role,team) VALUES (?,?,?,?,?,?)');
    const users = [
        ['adm1','ADM Principal','vendas02eduardo@gmail.com', bcrypt.hashSync('ADM#Pr1nC28!',10),'admin','ADMIN'],
        ['gabi','GABI','gabrieliguaztto.vendas@gmail.com', bcrypt.hashSync('GAB#D3MiGJ01!',10),'leader','LESTE'],
        ['hevellyn','Hevellyn','vendashevellyn2@gmail.com', bcrypt.hashSync('HEV#W1FLBr02!',10),'seller','LESTE']
    ];
    users.forEach(u=>stmt.run(u));
    stmt.finalize(()=>db.close());
});
